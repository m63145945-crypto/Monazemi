package com.example.monazemi;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    TaskDb db; Calendar selected=Calendar.getInstance(); LinearLayout root, days, list; TextView monthLabel, selectedLabel;
    int blue=Color.rgb(24,100,220);
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new TaskDb(this); if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},20); build(); }
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(25,45,75));t.setPadding(dp(8),dp(8),dp(8),dp(8));return t;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));return b;}
    void build(){
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(14),dp(12),dp(14),dp(12));root.setBackgroundColor(Color.rgb(244,248,255));
        ScrollView scroll=new ScrollView(this); LinearLayout content=new LinearLayout(this);content.setOrientation(1);scroll.addView(content);
        TextView title=text("📘 منظمي",26);title.setTypeface(null,Typeface.BOLD);title.setTextColor(blue);content.addView(title);
        TextView sub=text("خطط • ذاكر • أنجز",14);content.addView(sub);
        LinearLayout nav=new LinearLayout(this); Button prev=button("‹");Button next=button("›");monthLabel=text("",19);monthLabel.setTypeface(null,1);nav.addView(prev);nav.addView(monthLabel,new LinearLayout.LayoutParams(0,dp(52),1));nav.addView(next);content.addView(nav);
        prev.setOnClickListener(v->{selected.add(Calendar.MONTH,-1);drawCalendar();});next.setOnClickListener(v->{selected.add(Calendar.MONTH,1);drawCalendar();});
        days=new LinearLayout(this);days.setOrientation(1);content.addView(days);
        selectedLabel=text("",18);selectedLabel.setTypeface(null,1);content.addView(selectedLabel);
        Button add=button("+ إضافة مهمة لهذا اليوم");content.addView(add);add.setOnClickListener(v->addTask());
        list=new LinearLayout(this);list.setOrientation(1);content.addView(list);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);drawCalendar();
    }
    void drawCalendar(){
        monthLabel.setText(new SimpleDateFormat("MMMM yyyy",new Locale("ar")).format(selected.getTime()));
        days.removeAllViews();
        String[] headers={"أحد","اثنين","ثلاثاء","أربعاء","خميس","جمعة","سبت"};
        LinearLayout header=new LinearLayout(this);for(String h:headers){TextView t=text(h,12);t.setGravity(Gravity.CENTER);header.addView(t,new LinearLayout.LayoutParams(0,dp(36),1));}days.addView(header);
        Calendar c=(Calendar)selected.clone();c.set(Calendar.DAY_OF_MONTH,1);int offset=c.get(Calendar.DAY_OF_WEEK)-1;int max=c.getActualMaximum(Calendar.DAY_OF_MONTH);
        int day=1;
        for(int r=0;r<6 && day<=max;r++){LinearLayout row=new LinearLayout(this);for(int col=0;col<7;col++){TextView cell=text("",15);cell.setGravity(Gravity.CENTER);cell.setBackgroundTintList(null);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(44),1);if((r==0&&col<offset)||day>max){row.addView(cell,lp);continue;}final int d=day++;cell.setText(String.valueOf(d));if(d==selected.get(Calendar.DAY_OF_MONTH)){cell.setTextColor(Color.WHITE);cell.setBackgroundColor(blue);}else cell.setBackgroundColor(Color.WHITE);cell.setOnClickListener(v->{selected.set(Calendar.DAY_OF_MONTH,d);drawCalendar();});row.addView(cell,lp);}days.addView(row);}
        selectedLabel.setText("مهام يوم "+new SimpleDateFormat("EEEE d MMMM yyyy",new Locale("ar")).format(selected.getTime()));drawTasks();
    }
    String selectedKey(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.getTime());}
    void addTask(){
        EditText input=new EditText(this);input.setHint("اكتب المهمة");EditText time=new EditText(this);time.setHint("وقت التذكير مثل 18:30");time.setInputType(2);
        CheckBox daily=new CheckBox(this);daily.setText("تكرار يوميًا");
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(12),dp(8),dp(12),dp(8));box.setOrientation(1);box.addView(input);box.addView(time);box.addView(daily);
        new AlertDialog.Builder(this).setTitle("مهمة جديدة").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{
            String title=input.getText().toString().trim();if(title.isEmpty()){Toast.makeText(this,"اكتب اسم المهمة أولًا",Toast.LENGTH_LONG).show();return;}
            int h=18,m=0;String[] parts=time.getText().toString().trim().split(":");try{if(parts.length==2){h=Integer.parseInt(parts[0]);m=Integer.parseInt(parts[1]);if(h<0||h>23||m<0||m>59)throw new Exception();}}catch(Exception ex){Toast.makeText(this,"اكتب الوقت بصيغة 18:30",Toast.LENGTH_LONG).show();return;}
            long id=db.add(title,selectedKey(),h,m,daily.isChecked());Calendar c=(Calendar)selected.clone();c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,m);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis()&&daily.isChecked())c.add(Calendar.DAY_OF_YEAR,1);
            if(c.getTimeInMillis()>System.currentTimeMillis())schedule(this,id,title,c.getTimeInMillis());
            Toast.makeText(this,"تم حفظ المهمة على الهاتف",Toast.LENGTH_SHORT).show();drawTasks();
        }).show();
    }
    static void schedule(Context ctx,long id,String title,long when){
        Intent i=new Intent(ctx,ReminderReceiver.class);i.putExtra("title",title);i.putExtra("taskId",(int)id);
        PendingIntent pi=PendingIntent.getBroadcast(ctx,(int)id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)ctx.getSystemService(ALARM_SERVICE);
        if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);else am.set(AlarmManager.RTC_WAKEUP,when,pi);
    }
    void drawTasks(){
        list.removeAllViews();ArrayList<TaskDb.Task> tasks=db.forDate(selectedKey());
        if(tasks.isEmpty()){list.addView(text("لا توجد مهام لهذا اليوم. أضف أول مهمة!",15));return;}
        for(TaskDb.Task task:tasks){LinearLayout row=new LinearLayout(this);row.setOrientation(0);row.setBackgroundColor(Color.WHITE);CheckBox done=new CheckBox(this);done.setChecked(task.done);done.setOnCheckedChangeListener((b,v)->{db.setDone(task.id,v);drawTasks();});row.addView(done);
            TextView name=text(task.title+"\n"+String.format(Locale.US,"%02d:%02d",task.hour,task.minute)+(task.daily?" • يوميًا":""),16);row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            Button del=new Button(this);del.setText("حذف");del.setOnClickListener(v->{new AlertDialog.Builder(this).setMessage("هل تريد حذف المهمة؟").setNegativeButton("لا",null).setPositiveButton("نعم",(a,z)->{db.delete(task.id);drawTasks();}).show();});row.addView(del);list.addView(row);View gap=new View(this);list.addView(gap,new LinearLayout.LayoutParams(1,dp(6)));}
    }
}
