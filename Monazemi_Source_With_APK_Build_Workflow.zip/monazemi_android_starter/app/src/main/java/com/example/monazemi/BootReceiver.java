package com.example.monazemi;

import android.content.*;
import android.app.*;
import java.util.*;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if(!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        TaskDb db=new TaskDb(context);
        for(TaskDb.Task t:db.all()) {
            if(t.done) continue;
            try {
                java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US);
                Date d=f.parse(t.due); Calendar c=Calendar.getInstance(); c.setTime(d);
                c.set(Calendar.HOUR_OF_DAY,t.hour); c.set(Calendar.MINUTE,t.minute); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
                if(t.daily) { Calendar now=Calendar.getInstance(); if(c.before(now)) c.add(Calendar.DAY_OF_YEAR,1); }
                if(c.getTimeInMillis()<=System.currentTimeMillis()) continue;
                MainActivity.schedule(context,t.id,t.title,c.getTimeInMillis());
            } catch(Exception ignored) {}
        }
    }
}
