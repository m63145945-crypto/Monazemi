package com.example.monazemi;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class TaskDb extends SQLiteOpenHelper {
    public TaskDb(Context c) { super(c, "monazemi.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, due TEXT NOT NULL, hour INTEGER NOT NULL, minute INTEGER NOT NULL, done INTEGER NOT NULL DEFAULT 0, repeat_daily INTEGER NOT NULL DEFAULT 0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {}
    public long add(String title, String due, int hour, int minute, boolean daily) {
        ContentValues v=new ContentValues(); v.put("title",title); v.put("due",due);
        v.put("hour",hour); v.put("minute",minute); v.put("repeat_daily",daily?1:0);
        return getWritableDatabase().insertOrThrow("tasks",null,v);
    }
    public ArrayList<Task> forDate(String date) {
        ArrayList<Task> a=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT id,title,due,hour,minute,done,repeat_daily FROM tasks WHERE due=? OR repeat_daily=1 ORDER BY hour,minute",new String[]{date});
        try { while(c.moveToNext()) a.add(new Task(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getInt(4),c.getInt(5)==1,c.getInt(6)==1)); }
        finally { c.close(); } return a;
    }
    public ArrayList<Task> all() {
        ArrayList<Task> a=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT id,title,due,hour,minute,done,repeat_daily FROM tasks",null);
        try { while(c.moveToNext()) a.add(new Task(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getInt(4),c.getInt(5)==1,c.getInt(6)==1)); }
        finally { c.close(); } return a;
    }
    public void setDone(long id, boolean done) {
        ContentValues v=new ContentValues(); v.put("done",done?1:0);
        getWritableDatabase().update("tasks",v,"id=?",new String[]{String.valueOf(id)});
    }
    public void delete(long id) { getWritableDatabase().delete("tasks","id=?",new String[]{String.valueOf(id)}); }
    public static class Task {
        public long id; public String title,due; public int hour,minute; public boolean done,daily;
        public Task(long i,String t,String d,int h,int m,boolean dn,boolean dy){id=i;title=t;due=d;hour=h;minute=m;done=dn;daily=dy;}
    }
}
