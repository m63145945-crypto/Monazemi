package com.example.monazemi;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL="study_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        String title=intent.getStringExtra("title");
        if(title==null) title="لديك مهمة للمذاكرة";
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CHANNEL,"تذكيرات المهام",NotificationManager.IMPORTANCE_HIGH));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,CHANNEL):new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("منظمي — تذكير").setContentText(title).setAutoCancel(true);
        nm.notify(intent.getIntExtra("taskId",1),b.build());
    }
}
